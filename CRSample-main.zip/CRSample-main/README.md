# SimpleCRUD for Code Review

user : admin\
pass : admin
